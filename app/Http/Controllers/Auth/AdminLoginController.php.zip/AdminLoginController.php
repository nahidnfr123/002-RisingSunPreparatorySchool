<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminLoginController extends Controller
{
    public function __construct()
    {
        $this->middleware('guest:admin')->except('logout');
    }

    public function showAdminLoginForm(){
        return view('admin.authentication.login');
    }

    public function login(Request $request){
        // Validate form data ...
        $this->validate($request, [
            'email' => 'required|email',
            'password' => 'required|min:8|max:60',
        ]);

        // Attempt to login the user ...
        if(Auth::guard('admin')->attempt(['email'=>$request->email, 'password' => $request->password], $request->remember)){
            // On success ... redirect to intended page ...
            if(Auth::guard('admin')->user()->roles->pluck('name')->first() === 'User'){ // user tried to login to the admin panel ....
                Auth::guard('admin')->logout();
                return back()->with('Error', 'Wrong Email or Password.');
            }
            return redirect()->intended(route('admin.dashboard'));
        }
        // Not success ... return back with data ...
        return redirect()->back()->with('Error', 'Wrong Email or Password.')->exceptInput('password');

        //return redirect()->back()->withInput($request->Input::only('email', 'remember'));
    }
}
